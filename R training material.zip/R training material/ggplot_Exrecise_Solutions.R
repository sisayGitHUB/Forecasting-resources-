getwd()
library(ggplot2)
Emp<-read.csv('Employee data.csv')

g<-function(x){
  if(x=='f'){
    return('Female')
  }else{
    return('Male')
  }
}

job<-function(z){
  if (z==1){
    return('Clerical')
  }else if(z==2){
    return('Custodial')
  }else{
    return('Manager')
  }
}

# ggplot Exersise solutions

#Step One: Load the data
Emp_data<-read.csv('Employee data.csv')
# load the libraries
library(ggplot2)

# Question1:Scatter plot of (Beginning salary vs salary
ggplot(Emp_data, aes(salary, salbegin))+
  geom_point()+coord_cartesian(ylim = c(10000,60000))

# Question2: Histogram of salary
ggplot(Emp_data, aes(salary))+geom_histogram()+
  coord_cartesian(xlim=c(15750, 50000))

# Quetion3: Histogram of Salary
#(for both male and female separately)
ggplot(Emp_data, aes(salary))+geom_histogram(aes(fill=gender))

ggplot(Emp_data, aes(salary))+geom_histogram()+
  facet_grid(gender~.)

ggplot(Emp_data, aes(salary))+geom_histogram()+
  facet_grid(jobcat~.)

#Box plot of salary vs gender
ggplot(Emp_data, aes(gender, salary))+
  geom_boxplot(aes(fill=gender))

# bar plot for jobcat
ggplot(Emp_data, aes(jobcat, fill=gender))+
  geom_bar(position='dodge')

ggplot(Emp_data, aes(jobcat))+
  geom_bar(aes(fill=gender), position='dodge')



