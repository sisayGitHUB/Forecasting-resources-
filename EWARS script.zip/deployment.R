
library(rsconnect)

app.dir <-"C:/Users/NCoordinatorCSDSS/Desktop/EWARS_Plus_Server-main"
appName<-'EWARS_Plus_Ethiopia'
account = "ewars-ethiopia"
deployApp(appDir = app.dir, appName = appName,account = account, forceUpdate = T,launch.browser=F )
#configureApp( appDir = app.dir, redeploy = TRUE, appName = appName,  account = account, size = "xxxlarge") #instances=1, logLevel="quiet"

