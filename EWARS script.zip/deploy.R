
library(rsconnect)

app.dir <-"C:/Users/Sisay/Desktop/EWARS/EWARS_Plus_Server-main"
appName<-'EWARS_Ethiopia'
deployApp(appDir = app.dir, appName = appName, forceUpdate = T, launch.browser=F )
# configureApp( appDir = app.dir, redeploy = TRUE, appName = appName, size = "xxxarge") #instances=1, logLevel="quiet")
              

              