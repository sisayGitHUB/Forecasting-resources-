library(readxl)
library(dplyr)
library(openxlsx)

# Set the path to your Excel file
file_path <- "C:/Users/Sisay/Desktop/PHEM2016EFY/Cholera Modeling/Cholera_ETH/Sisay_Cholera modelling/Sisay data_Final/Metadata2.xlsx"

# Read the data from the two sheets
Metadata2 <- read_excel(file_path, sheet = "Metadata2")
Population2022_24 <- read_excel(file_path, sheet = "WoredaPopulation2022_24")

Metadata_Final <- Metadata2 %>%
  left_join(Population2022_24, by = c("year","woreda"), suffix = c(".old", "")) %>%
  mutate(across(ends_with(".old"), ~ ifelse(!is.na(get(sub(".old", "", cur_column()))), get(sub(".old", "", cur_column())), .), .names = "{sub('.old', '', .col)}")) %>%
  select(-ends_with(".old"))

# Optionally, save the linked data to a new Excel file
write.xlsx(Metadata_Final, "Metadata_Final.xlsx", row.names = FALSE)



#######################################
####### Trial 2 #####
pacman::p_load(dplyr, tidyverse, magrittr, fuzzyjoin, lubridate, epitrix, 
               openxlsx, here, rio, sf)
source(here::here("scripts", "0_functions.R"))
# Read the data from the two sheets
Metadata<-rio::import(here::here("Metadata_popu2022_24","Metadata2.xlsx"),which = "Metadata2")
Population2022_24 <- rio::import(here::here("Metadata_popu2022_24","Metadata2.xlsx"),which = "WoredaPopulation2022_24")

woreda_names <- Metadata$woreda %>% unique() %>% tolower()

Metadata_woreda <- Metadata %>% select(year, woreda, population) %>% unique()
Metadata_woreda_check <- woreda_check(Metadata_woreda, woreda_names)

Population2022_24_woreda <- Population2022_24$woreda %>% unique()%>% tolower()
woreda_check <- sum(Population2022_24_woreda %in% tolower(woreda_names)) == length(Population2022_24_woreda)
if(woreda_check){
  print("Woreda names are clean!")
}else{
  toclean <- Population2022_24_woreda[!Population2022_24_woreda %in% tolower(woreda_names)]
  
  df_toclean <- data.frame(woreda = toclean)
  df_ref <- data.frame(suggested = woreda_names)
  
  matched <- fuzzyjoin::stringdist_join(df_toclean,
                                        df_ref,
                                        mode = "inner",
                                        by = c("woreda"="suggested"),
                                        max_dist = 5,
                                        ignore_case=T,
                                        method = "lcs")
  
  cleaning_list <- merge(df_toclean, matched, by = "woreda", all.x=T) %>% mutate(
    Mark = NA
  )
  
  header_style <- createStyle(halign = "center", fontColour = "black", 
                              textDecoration = "bold", fgFill = "#cce8d4")
  
  wb <- loadWorkbook(here::here("For cleaning", "to_clean2.xlsx"))
  writeData(wb, "Cleaning", cleaning_list, headerStyle = header_style)
  freezePane(wb, "Cleaning", firstRow = TRUE)
  writeData(wb, "Ref", df_ref %>% arrange(suggested), headerStyle = header_style)
  freezePane(wb, "Ref", firstRow = TRUE)
  
  saveWorkbook(wb, here::here("For cleaning", paste0("to_clean2_", substr(gsub("[^0-9]", "", Sys.time()), 1, 12), ".xlsx")),
               overwrite=T)
  print("Go to the following directory and update the file following the instruction.")
  print(here::here("For cleaning", paste0("to_clean2_", substr(gsub("[^0-9]", "", Sys.time()), 1, 12), ".xlsx")))
  
}


### Run this part after cleaning sheet is completed
cleaned <- rio::import(here::here("For cleaning", "to_clean2_202408231218.xlsx"),
                       which = "Cleaning")

cleaned %<>% filter(!is.na(Mark))  %>% mutate(
  Mark = ifelse(Mark=="X", suggested, Mark)
)%>% select(-suggested)
colnames(cleaned) <- c("woreda", "woreda_name")

Population2022_24<-Population2022_24%>%mutate(woreda = tolower(woreda))

Population2022_24_updated <- merge(Population2022_24, cleaned, by = "woreda", all.x = TRUE)
Population2022_24_updated <-transform(Population2022_24_updated, woreda_name = ifelse(is.na(woreda_name), 
              woreda, as.character(woreda_name)))
Population2022_24_updated <-Population2022_24_updated %>%relocate(woreda_name, .before = year)%>%
  select(-woreda)
colnames(Population2022_24_updated)[1] = "woreda"

Population2022_24_updated_woreda <- Population2022_24_updated$woreda %>% unique()%>% tolower()
cleaned_woreda <- cleaned$woreda_name %>% unique()%>% tolower()

#sum(Population2022_24_updated_woreda%in%woreda_names)


# Aggregate annual figures
Metadata<-Metadata%>%mutate(woreda = tolower(woreda))
head(Metadata_updated)  
Metadata_updated <- merge(Metadata, Population2022_24_updated, by = c("woreda","year"), all.x = TRUE)
Metadata_updated <-transform(Metadata_updated, population = ifelse(is.na(population.y), 
                                                  population.x, population.y))
Metadata_updated  <-Metadata_updated %>%relocate(population, .before = week)%>%
  select(-c(population.x,population.y))

rio::export(Metadata_updated,
            here::here("clean data", paste0("Metadata_Final3", substr(gsub("[^0-9]", "", Sys.time()), 1, 12), ".xlsx")))



####### Prospective data ###################3

Metadata_prospective<-rio::import(here::here("Prospective Data","Metadata_Prospective.xlsx"))
prospective_weather<-rio::import(here::here("Prospective Data","ethiopia_era5_1998.xlsx"), which="prospective1998")
prospective_weather<-prospective_weather%>% select(-year)

Metadata_prospective<- Metadata_prospective %>% mutate(woreda = tolower(woreda))
prospective_weather<- prospective_weather %>% mutate(woreda = tolower(woreda))

Prospective_final <- merge(Metadata_prospective, prospective_weather, by = c("woreda", "week"), all.x = TRUE)
#Prospective_final <-transform(Prospective_final, Rainfall = ifelse(is.na(Rainfall.y), Rainfall.x, Rainfall.y))%>%
  #transform(Prospective_final,district_code = ifelse(is.na(district_code.y), district_code.x, district_code.y))
Prospective_final <-Prospective_final %>% select(-c("Rainfall.x", "mean_temp.x","district_code.x", "x.x", "y.x"))
colnames(Prospective_final)<-c("woreda", "week", "year", "population", "n_cholera", "ocv_cov", "mean_temp", "Rainfall", "district_code", "x", "y")

rio::export(Prospective_final,
            here::here("Prospective Data", paste0("Prospective_final",  ".xlsx")))

head(Prospective_final)


##### district code ########

Metadata_Final<-rio::import(here::here("Prospective Data","Metadata_Final.xlsx"))
Metadata_Final<- Metadata_Final %>% mutate(woreda = tolower(woreda))

Metadata_Retrospective <- merge(Metadata_Final, prospective_weather, by = c("woreda", "week"), all.x = TRUE)
Metadata_Retrospective <-Metadata_Retrospective %>% select(-c("Rainfall.y", "mean_temp.y"))
colnames(Metadata_Retrospective)<-c("woreda", "week", "year","population", "n_cholera","Rainfall","mean_temp","ocv_cov","district_code", "x", "y")

rio::export(Metadata_Retrospective,
            here::here("Prospective Data", paste0("Metadata_Retrospective",  ".xlsx")))

