woreda_check <- function(woreda_names, ref_names){
  if(is.data.frame(woreda_names)){
    return(sum(woreda_names[,2] %in% ref_names)==nrow(woreda_names))
  }else{
    return(sum(woreda_names %in% ref_names)==length(woreda_names))
  }
}

initiate_cleaning <- function(woreda_df, ref_names){
  
  # When there are woreda names that don't match, we initiate the manual cleaning
  if(is.data.frame(woreda_df)){
    woreda_names <- woreda_df[,2]
    toclean <- woreda_df[!tolower(woreda_names) %in% tolower(ref_names),] %>%
    mutate_all(tolower)
    df_toclean <- data.frame(woreda = toclean[,2])
    
  }else{
    woreda_names <- woreda_df
    toclean <- woreda_names[!tolower(woreda_names) %in% tolower(ref_names)] %>% tolower()
    df_toclean <- data.frame(woreda = toclean)
    
  }

  df_ref <- data.frame(suggested = ref_names)
  
  matched <- fuzzyjoin::stringdist_join(df_toclean,
                                        df_ref,
                                        mode = "inner",
                                        by = c("woreda"="suggested"),
                                        max_dist = 5,
                                        ignore_case=T,
                                        method = "lcs")
  
  if(is.data.frame(woreda_df)){
    cleaning_list <- merge(toclean, matched, by = "woreda", all.x=T) %>% mutate(
      Mark = NA
    )
    cleaning_list %<>% .[,c(2,1,3,4)]
  }else{
    cleaning_list <- merge(df_toclean, matched, by = "woreda", all.x=T) %>% mutate(
      Mark = NA
    )
  }
  
  header_style <- createStyle(halign = "center", fontColour = "black", 
                              textDecoration = "bold", fgFill = "#cce8d4")
  
  wb <- loadWorkbook(here::here("For cleaning", "(DO NOT DELETE) to_clean_template.xlsx"))
  writeData(wb, "Cleaning", cleaning_list, headerStyle = header_style)
  freezePane(wb, "Cleaning", firstRow = TRUE)
  writeData(wb, "Ref", df_ref %>% arrange(suggested), headerStyle = header_style)
  freezePane(wb, "Ref", firstRow = TRUE)
  
  saveWorkbook(wb, here::here("For cleaning", paste0("to_clean_", substr(gsub("[^0-9]", "", Sys.time()), 1, 12), ".xlsx")),
               overwrite=T)
  print("Go to the following directory and update the file following the instruction.")
  print(here::here("For cleaning", paste0("to_clean_", substr(gsub("[^0-9]", "", Sys.time()), 1, 12), ".xlsx")))
}

update_clean_names <- function(filepath, dat, geocode=F){
  if(geocode){
    cleaned <- rio::import(filepath,
                           which = "Cleaning")
    cleaned %<>% filter(!is.na(Mark))  %>% mutate(
      Mark = ifelse(Mark=="X", suggested, Mark)
    )%>% select(woreda, Mark)
    colnames(cleaned) <- c("geo_id_ref", "geo_id_admin2")
    
    dat %<>% mutate(
      geo_id_ref = geo_id_admin2
    ) %>%
      rows_update(cleaned, by = "geo_id_ref")
  }else{
  cleaned <- rio::import(filepath,
                         which = "Cleaning")
  cleaned %<>% filter(!is.na(Mark))  %>% mutate(
    Mark = ifelse(Mark=="X", suggested, Mark)
  )%>% select(woreda, Mark)
  colnames(cleaned) <- c("woreda_name", "woreda")
  
  dat %<>% mutate(
    woreda_name = tolower(woreda),
    woreda = tolower(woreda)
  ) %>%
    rows_update(cleaned, by = "woreda_name", unmatched = "ignore")
}
  
return(dat)
  
}

