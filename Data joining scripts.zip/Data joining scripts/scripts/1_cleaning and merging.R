pacman::p_load(dplyr, tidyverse, magrittr, fuzzyjoin, lubridate, epitrix, 
               openxlsx, here, rio, sf)
source(here::here("scripts", "0_functions.R"))

###### Load linelist data ######
## Change the file directory to your appropriate locations.
## As long as the files are in the same structure, this code will work.

# Linelist (I copy-pasted the variable names to the first row of this tab before doing this)
linelist <- rio::import(here::here("Sisay data", "Demo_line_list_2015_2021.xlsx"),
                        which = "ll_2015_2021")

linelist2 <- rio::import(here::here("Sisay data", "Demo_lineList_2022-24.xlsx"),
                                    which = "Line list")

# Geocode reference
ethiopia <- read_sf(dsn = here::here("Sisay data", "ETshapeFile" ,
                                     "ETshapefile.shp"))
geo_ref <- ethiopia %>% select(ADM3_EN, ADM3_PCODE) %>% st_drop_geometry()
colnames(geo_ref) <- c("admin2", "geo_id_admin2")

# Annual population size
population <- rio::import(here::here("Sisay data", "Demo_line_list_2015_2021.xlsx"),
                          which = "population_15_23_by_woreda")

population2 <- rio::import(here::here("Sisay data", "Demo_line_list_2015_2021.xlsx"),
                           which = "geo_unit_tab_correspondence")
population %<>% left_join(population2 %<>% select(geo_id_admin2, admin2))

###### Load OCV data #####
ocv <- rio::import(here::here("Sisay data", "OCV Campaign dataformodeling.xlsx"))


###### Create a template to store all the data ######

# Specify the start and end year
start_year <- 2015
end_year <- 2024
n_year <- length(c(start_year:end_year))

# Extract standardized woreda names from teh geocode reference sheet
woreda_names <- geo_ref$admin2 %>% unique() %>% tolower()
n_woreda <- length(woreda_names)

# Populate the empty template
chol_dat <- data.frame(
  year = rep(rep(c(start_year:end_year), each = 52), n_woreda),
  woreda = rep(woreda_names, each = 52*n_year),
  week = rep(1:52, n_year*n_woreda),
  pop = NaN,
  n_cholera = 0,
  rainfall = NaN,
  mean_temp = NaN,
  ocv_cov = NaN,
  safe_water_cov = NaN,
  handwash_cov = NaN
)

##### Clean the data and merge#####

### Linelist ###

# Merge two linelist into one (key variables only)
colnames(linelist2) %<>% epitrix::clean_labels()
linelist2_sub <- linelist2 %>% select(woreda, epi_week_date_seen_at_hf, year_date_seen_at_hf)
colnames(linelist2_sub) <- c("woreda", "iso_week", "iso_year")

# Check if all woreda names in the file match with the standard names
linelist %<>% mutate(
  woreda = tolower(admin2)
)

linelist %<>% bind_rows(linelist2_sub)

linelist_woreda <- linelist %>% select(admin1, woreda) %>% unique()
ll_woreda_check <- woreda_check(linelist_woreda, woreda_names)

# If everything matches, we skip the cleaning part
if(ll_woreda_check){
  print("Woreda names in the linelist file are clean!")
}else{
  initiate_cleaning(linelist_woreda, woreda_names)
}

# Run this line with the updated file path to the completed cleaning sheet
if(!ll_woreda_check){
  # Update the woreda name
  linelist <- update_clean_names(here::here("For cleaning", "to_clean_202408011300.xlsx"),
                                 linelist) # <---- update this path
  
  # Re-check 
  linelist_woreda <- linelist$woreda %>% unique()
  ll_woreda_check <- woreda_check(linelist_woreda, woreda_names)
  if(ll_woreda_check){
    print("Woreda names are clean!")
  }else{
    excluded <- linelist$woreda[!linelist$woreda %in% woreda_names] %>% unique()
    print("Following woredas won't be included:")
    print(excluded)
    linelist %<>% filter(!woreda %in% excluded)
  }
}

# Convert date into correct format
#linelist %<>% mutate_at(vars(contains("date")), function(x){
#  as.Date(x, format = "%Y-%M-%d")
#})
  
# Aggregate based on epiweeks
weekly_chol <- linelist %>% mutate(
  # Use the ISO year and week from the line list as it is (recommended)
  year = as.numeric(iso_year),
  week = as.numeric(iso_week)
  # Extract year and ISO week number (if we want to use the Date of Onset)
  #year = lubridate::year(date_onset_c),
  #week = lubridate::isoweek(date_onset_c)
) %>% group_by(woreda, year, week) %>%
  # Summarize the linelist case counts
  summarize(
    n_cholera = n(),
  ) %>% ungroup()

# Merge into the template
weekly_chol %<>% filter(year %in% start_year:end_year)
chol_dat %<>% rows_update(weekly_chol, by = c("year", "week", "woreda"))

# Confirming plot
ggthemr::ggthemr("fresh")
weekly_chol %>% ggplot(aes(week, n_cholera, 
                group = as.factor(year), color = as.factor(year), fill = as.factor(year))) + 
  geom_point() + geom_path() + 
  scale_color_discrete(name = "Year")+
  scale_fill_discrete(guide = "none")+
  facet_wrap(.~woreda, scales = "free_y") +
  theme(strip.text = element_text(face = "bold"))
  

### Population size ###

# Check if all admin2 codes match with the standard codes
pop_woreda <- population %>% select(geo_id_admin2, admin2) %>% unique() %>% 
  mutate_all(tolower)
colnames(pop_woreda)[2] <- "woreda"
pop_woreda_check <- woreda_check(pop_woreda, woreda_names)

# If everything matches, we skip the cleaning part
if(pop_woreda_check){
  print("Woreda geocodes in the population file are clean!")
}else{
  initiate_cleaning(pop_woreda, woreda_names)
}

population %<>% mutate(
  woreda = tolower(admin2)
)

# Run this line with the updated file path to the completed cleaning sheet
if(!pop_woreda_check){
  # Update the woreda name
  population <- update_clean_names(here::here("For cleaning", "to_clean_202408011325.xlsx"),
                                   population) # <---- update this path
  
  # Re-check if all admin2 codes match with the standard codes
  pop_woreda <- population$woreda %>% unique() %>% tolower()
  pop_woreda_check <- woreda_check(pop_woreda, woreda_names)
  
  if(pop_woreda_check){
    print("Woreda geocodes are clean!")
  }else{
    excluded <- population$woreda[!population$woreda %in% woreda_names] %>% unique()
    print("Following woredas won't be included:")
    print(excluded)
    population %<>% filter(!woreda %in% excluded)
  }
}

# Convert columns into correct format
population %<>% mutate(
  year = as.numeric(year)
)

# Only choose relevant columns
population_yr <- population %>% select(year, pop, woreda)

# Merge into the template
population_yr %<>% filter(year %in% start_year:end_year)
chol_dat %<>% rows_update(population_yr, by = c("year", "woreda"))


### OCV coverage ###

# Clean variable names
colnames(ocv) %<>% epitrix::clean_labels()

# Modify some columns
ocv%<>% mutate(
  woreda = tolower(woreda_name)
)

# Check if all woreda names match with the standard codes
ocv_woreda <- ocv %>% select(zone_name, woreda) %>% unique() %>% mutate_all(tolower)
ocv_woreda_check <- woreda_check(ocv_woreda, woreda_names)

# If everything matches, we skip the cleaning part
if(ocv_woreda_check){
  print("Woreda names in OCV dataset are clean!")
}else{
# When there are woreda names that don't match, we initiate the manual cleaning
  initiate_cleaning(ocv_woreda, woreda_names)
}

### Run this part after cleaning sheet is completed
if(!ocv_woreda_check){
  ocv <- update_clean_names(here::here("For cleaning", "to_clean_202408011351.xlsx"),
                              ocv)
  ocv_woreda_new <- ocv$woreda %>% unique()
  ocv_woreda_check <- woreda_check(ocv_woreda_new, woreda_names)
  if(ocv_woreda_check){
  print("Woreda names are clean!")
  }else{
    excluded <- ocv$woreda[!ocv$woreda %in% woreda_names] %>% unique()
    print("Following woredas won't be included:")
    print(excluded)
    ocv %<>% filter(!woreda %in% excluded)
  }
}
# Aggregate annual figures
ocv_yr <- ocv %>% group_by(year, woreda) %>% summarize(
  ocv_cov = mean(coverage_from_target_population, na.rm=T)
) %>% ungroup() %>% 
  filter(year %in% start_year:end_year)


chol_dat %<>% rows_update(ocv_yr, by = c("year", "woreda"))

################# Merge with weather data

weather <- rio::import(here::here("Sisay data", "era5_weekly_2019_2024.csv"))
str(weather)

# Modify some columns
weather%<>% mutate(
  woreda = tolower(woreda)
)

# Check if all woreda names match with the standard codes
weather_woreda <- weather$woreda %>% unique()
weather_woreda_check <- woreda_check(weather_woreda, woreda_names)

# If everything matches, we skip the cleaning part
if(weather_woreda_check){
  print("woreda names in weather dataset are clean!")
}else{
  # When there are woreda names that don't match, we initiate the manual cleaning
  initiate_cleaning(weather_woreda, woreda_names)
}

### Run this part after cleaning sheet is completed
if(!weather_woreda_check){
  weather <- update_clean_names(here::here("For cleaning", "to_clean_202408011400.xlsx"),
                            weather)
  weather_woreda_new <- weather$woreda %>% unique()
  weather_woreda_check <- woreda_check(weather_woreda_new, woreda_names)
  if(weather_woreda_check){
    print("Woreda names are clean!")
  }else{
    excluded <- weather$woreda[!weather$woreda %in% woreda_names] %>% unique()
    print("Following woredas won't be included:")
    print(excluded)
    weather %<>% filter(!woreda %in% excluded)
  }
}

weather %<>% select(-woreda_name)

chol_dat %<>% mutate(
  rainfall = as.numeric(rainfall),
  mean_temp = as.numeric(mean_temp)) %>% 
  rows_update(weather, by = c("year", "week", "woreda")
              , unmatched = 'ignore')

###### Save the merged data into the "clean data" folder ######
rio::export(chol_dat,
            here::here("clean data", paste0("chol_data_", substr(gsub("[^0-9]", "", Sys.time()), 1, 12), ".csv")))


